import { createStore } from 'vuex'

export default createStore({
  state: {    
    pasteles:[             
      { id:1,
        tamano:'Individual',
        precio: 80,
        imagen: require('@/assets/imgs/p-individual.jpeg')      
    },
    {
      id:2,
      tamano:'Chico',
      precio: 180,
      imagen: require('@/assets/imgs/p-chico.jpeg')
    },
    {
      id:3,
      tamano:'Mediano',
      precio: 280,
      imagen: require('@/assets/imgs/p-mediano.jpeg')
    },
    {
      id:4,
      tamano:'Grande',
      precio: 350,
      imagen: require('@/assets/imgs/p-grande.jpeg')
    }
    ],
    sabores: [
      {
        id:1,
        sabor:'Chocolate',
        precio: 80,
        imagen: require('@/assets/imgs/p-chocolate-fresa.jpeg')      
      },
      {
        id:2,
        sabor:'Fresa',
        precio: 120,
        imagen: require('@/assets/imgs/p-fresa.jpeg')
      },
      {
        id:3,
        sabor:'Tres leches',
        precio: 100,
        imagen: require('@/assets/imgs/p-3Leches.jpeg')
      },
      {
        id:4,
        sabor:'Vainilla',
        precio: 150,
        imagen: require('@/assets/imgs/p-vainilla.jpeg')
      }
    ],
    decoraciones: [
      {
        id:1,
        adorno:'Fresas Naturales',
        precio: 80,
        imagen: require('@/assets/imgs/d-Fresas.jpeg')      
      },
      {
        id:2,
        adorno:'Galletas Chispas de Chocolate',
        precio: 50,
        imagen: require('@/assets/imgs/d-galletasChispas.jpeg')
      },
      {
        id:3,
        adorno:'Almendras',
        precio: 100,
        imagen: require('@/assets/imgs/d-almendras.jpeg')
      },
      {
        id:4,
        adorno:'Frutos Secos',
        precio: 150,
        imagen: require('@/assets/imgs/d-frutosSecos.jpeg')
      }
     
    ],
    clientes: [],
    cliente : {},

    pedidos:[],
    tamano:'',
    sabor:'',
    decoracion:'',

    //Sabores en Existencia
    stockSabores: [
      {
        id:1, 
        nombre:'Chocolate', 
        cantidad:10, 
        existencia:5,
        unidad:'Kg'        
      },
      {
        id:2, 
        nombre:'Fresas', 
        cantidad:20, 
        existencia:5,
        unidad:'Cajas'
      },
      {
        id:3, 
        nombre:'Leche', 
        cantidad:20, 
        existencia:10,
        unidad:'Lts'
      },
      {
        id:4, 
        nombre:'Vainilla', 
        cantidad:15, 
        existencia:8,
        unidad:'Lts'
      },    

    ],

    //Decoraciones en existencia
    stockDecoraciones: [
      {
        id:1, 
        nombre:'Fresas Naturales', 
        cantidad:35, 
        existencia:12,
        unidad:'Cajas'
      },
      {
        id:2, 
        nombre:'Betún', 
        cantidad:30, 
        existencia:20,
        unidad:'Kg'
      },
      {
        id:3, 
        nombre:'Galletas Chispas', 
        cantidad:20, 
        existencia:10,
        unidad:'Cajas'
      },
      {
        id:4, 
        nombre:'Frutos Secos', 
        cantidad:20, 
        existencia:12,
        unidad:'Kg'
      },
      {
        id:5, 
        nombre:'Almendras', 
        cantidad:15, 
        existencia:10,
        unidad:'Kg'
      },      

    ]

    
  },
  getters: {
    getPasteles(state)  {
      return state.pasteles;
    },
    getSabores(state) {
      return state.sabores
    },
    getDecoraciones(state) {
      return state.decoraciones
    },
    getStockSabores(state) {
      return state.stockSabores
    },
    getStockDecoraciones(state) {
      return state.stockDecoraciones
    },
    getPedidos(state) {
      return state.clientes;
    },       
  },
  mutations: {    
    pasteles(state){
     state.pasteles(state)
   },   
   sabores(state) {
     state.sabores(state)    
   },
   decoraciones(state) {
    state.decoraciones(state)    
  }, 
  stockSabores(state) {
    state.stockSabores(state)    
  },
  stockDecoraciones(state) {
    state.stockDecoraciones(state)    
  },
  pedidos(state) {
    state.pedidos(state)    
  },

  addPedidos(state, cliente) {            
    let id = state.clientes.length;
    cliente.id = id + 1;
    
    cliente.tamano = state.tamano;
    cliente.sabor = state.sabor;
    cliente.decoracion = state.decoracion;

    state.clientes.push(cliente);
  },
  setTamano(state, tamano) {
    state.tamano = tamano;
  },
  setSabor(state, sabor) {
    state.sabor = sabor;
  },
  setDecoracion(state, decoracion) {
    state.decoracion= decoracion;
  }
        
  },
  actions: {
    addPedidosAction({commit}, cliente) {
      commit('addPedidos', cliente);
    },
    setTamanoAction({commit}, tamano) {
      commit('setTamano', tamano);      
    },
    setSaborAction({commit}, sabor) {
      commit('setSabor', sabor);      
    },
    setDecoracionAction({commit}, decoracion) {
      commit('setDecoracion', decoracion);      
    }

  },
  modules: {

  }
})
