<template>
    <div>
        <div class="container">
            <h1 class="mt-5 text-center">Decoraciones en existencia</h1>
            <table class="table table-info table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Cantidad</th>
                        <th scope="col">Quedan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="stockDecoracion of $store.getters.getStockDecoraciones" :key="stockDecoracion.id">
                        <th scope="row">{{stockDecoracion.id}}</th>
                        <td>{{ stockDecoracion.nombre }}</td>
                        <td>{{ stockDecoracion.cantidad }} {{ stockDecoracion.unidad }}</td>
                        <td>{{ stockDecoracion.existencia }} {{ stockDecoracion.unidad }}</td>
                    </tr>                   
                </tbody>          
            </table>
        </div>
    </div>
</template>

<script>
export default {
    name: 'StockDecoraciones',      
}
</script>