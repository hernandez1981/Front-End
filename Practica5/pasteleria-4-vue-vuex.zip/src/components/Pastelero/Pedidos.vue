<template>
    <div>
        <div class="container">             
            <h1 class="mt-5 text-center">Pedidos realizados</h1>            
            <table class="table table info">
                <thead>
                    <tr>  
                        <th scope="col">#</th>                  
                        <th scope="col">Nombre</th>
                        <th scope="col">Teléfono</th>
                        <th scope="col">Email</th>
                        <th scope="col">Descripción pastel</th>
                        <th scope="col">Tamaño</th>
                        <th scope="col">Sabor</th>
                        <th scope="col">Decoración</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="pedido of $store.getters.getPedidos" :key="pedido.id">
                        <th scope="row">{{ pedido.id }}</th>
                        <td>{{ pedido.nombre }}</td>
                        <td>{{ pedido.telefono }}</td>
                        <td>{{ pedido.email }}</td>
                        <td>{{ pedido.descPastel }}</td>
                        <td>{{ pedido.tamano }}</td>
                        <td>{{ pedido.sabor }}</td>
                        <td>{{ pedido.decoracion }}</td>
                    </tr>   
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
export default {
    name: 'Pedidos',      
}
</script>