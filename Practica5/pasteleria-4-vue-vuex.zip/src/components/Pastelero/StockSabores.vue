<template>
    <div>
        <div class="container">
            <h1 class="mt-5 text-center">Sabores en existencia</h1>
            <table class="table table-info table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Cantidad</th>
                        <th scope="col">Quedan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="stockSabor of $store.getters.getStockSabores" :key="stockSabor.id">
                        <th scope="row">{{ stockSabor.id }}</th>
                        <td>{{ stockSabor.nombre }}</td>
                        <td>{{ stockSabor.cantidad }} {{ stockSabor.unidad }}</td>
                        <td>{{ stockSabor.existencia }} {{ stockSabor.unidad }}</td>
                    </tr>                   
                </tbody>          
            </table>
        </div>
        
    </div>
</template>

<script>
export default {
    name: 'StockSabores',
    
    
}
</script>