<template>
  <div class="album py-5 bg-light">
    <div class="container">  
      <h2 class="titulo">Sabores</h2>
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3">          
        <div v-for="sabor of $store.getters.getSabores" :key="sabor.id" class="col text-center">            
          <label class="card shadow-sm center pt-2 py-2">
            <div class="card-body">
              <h3>{{ sabor.sabor }}</h3>
              <h3> ${{ sabor.precio }}</h3>
              <img :src="sabor.imagen">
              <p>Seleccionar
                <input v-on:change= "setSabor" v-model="this.sabor" type="radio" name="sabor" :value="sabor.sabor">
              </p>
            </div>
          </label>
        </div>
      </div>
    </div>
  </div>            
</template>

<script>
export default {
    name: 'Sabores', 
    data() {
      return {
        sabor:''
      }
    },
    methods: {
      setSabor() {
        console.log(this.sabor)
        this.$store.dispatch('setSaborAction', this.sabor)
      }
    }  
    
}
</script>

<style scoped>    
    .titulo {
        font-size: 50x;  
    }

    .titulo-pasteles-text {
    font-size: 1.5rem;
    }
  
  .card{
      min-height: 222px !important;
    }

</style>


