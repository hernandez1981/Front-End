<template>
    <div>
        <footer class="text-muted py-5">
            <div class="container">
                <p class="float-end mb-1">
                <a href="#">Subir</a>        
                </p>
                <p class="mb-1 text-center">&copy; 2022, Katy Hernández.</p>
            </div>
        </footer>
    </div>
</template>

<script>
export default {
    name: 'Footer',
    
    
}
</script>