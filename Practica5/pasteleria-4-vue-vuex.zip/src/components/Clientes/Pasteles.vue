<template>
  <div class="album py-5 bg-light">
    <div class="container">  
      <h2 class="titulo">Pasteles</h2>
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3">          
        <div v-for="pastel of $store.getters.getPasteles" :key="pastel.id" class="col text-center">           
          <label class="card shadow-sm center pt-2 py-2">
            <div  class="card-body">                 
              <h3>{{ pastel.tamano }}</h3>
              <h3> ${{ pastel.precio }}</h3>
              <img :src="pastel.imagen">
              <p> Selecionar
                <input v-on:change= "setTamano" v-model="tamano" type="radio" name="tamano" :value="pastel.tamano">
              </p>
            </div>
          </label>           
        </div>
      </div>
    </div>   
  </div>            
</template>

<script>
export default {
    name: 'Pasteles',  
    data() {
      return {
        tamano:''
      }
    },
    methods: {
      setTamano(){
        console.log(this.tamano)
        this.$store.dispatch('setTamanoAction', this.tamano);
      }
    },     
}
</script>

<style scoped>    
    .titulo {
        font-size: 50x;  
    }

    .titulo-pasteles-text {
    font-size: 1.5rem;
    }

    .card{
      min-height: 218px !important;
    }
  
</style>


