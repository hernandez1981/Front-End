<template>
    <div class="text-center container">
        <h1>Bienvenido, encuentre los mejores pasteles de su preferencia.</h1>
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="@/assets/imgs/slider0.jpg" class="d-block w-100" alt="imagen0">                                      
                </div>
                <div class="carousel-item">
                    <img src="@/assets/imgs/slider1.jpg" class="d-block w-100" alt="imagen1">                    
                </div>
                <div class="carousel-item">
                    <img src="@/assets/imgs/slider2.jpg" class="d-block w-100" alt="imagen2">
                </div>
                <div class="carousel-item">
                    <img src="@/assets/imgs/slider3.jpg" class="d-block w-100" alt="imagen3">
                </div>
            </div>
        </div>        
    </div>
</template>

<script>
export default {
    name: 'Carousels',
    
    
}
</script>

