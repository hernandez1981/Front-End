<template>
  <div class="album py-5 bg-light">
    <div class="container">  
      <h2 class="titulo">Adornos</h2>
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3">          
        <div v-for="decoracion of $store.getters.getDecoraciones" :key="decoracion.id" class="col text-center">            
          <label class="card shadow-sm center pt-2 py-2">
            <div class="card-body">
              <h3>{{ decoracion.adorno }}</h3>
              <h3>${{ decoracion.precio }}</h3>
              <img :src="decoracion.imagen">
              <p>Seleccionar
                <input v-on:change= "setDecoracion" v-model="this.vDecoracion" type="radio" name="adorno" :value="decoracion.adorno">
              </p>
            </div>
          </label>
        </div>
      </div>
    </div> 
  </div>
</template>

<script>
export default {
    name: 'Decoraciones',
    data() {
      return {
        vDecoracion:''
      }
    },
    methods: {
      setDecoracion() {
        console.log(this.vDecoracion)
        this.$store.dispatch('setDecoracionAction', this.vDecoracion)
      }
    }  
}
</script>

<style scoped>
  .card{
      min-height: 250px !important;
    }
</style>