<template>
  <div>
    <header>
      <div class="collapse bg-dark" id="navbarHeader">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 col-md-7 py-4">
              <h4 class="text-white">Acerca de:</h4>
              <p class="text-white">Todos nuestros productos están hechos con amor, con sabores únicos e irresistibles.</p>
            </div>
            <div class="col-sm-4 offset-md-1 py-4">
              <ul>               
                <router-link :to="{name: 'home'}" exact>Inicio</router-link>
                <router-link :to="{name: 'pastelero'}">Pastelero</router-link>
                <!-- <router-link :to="{name: '/'}">Pedido</router-link>
                <router-link :to="{name: '/'}">Entregados</router-link> -->
                
              </ul>
              <h4 class="text-white">Contacto</h4>
              <ul class="list-unstyled">
                <li>Dirección: Belizario Domínguez #320, Los Mochis, Sinaloa. </li>
                <li>Llamar al teléfono <a href="tel:6681596965" class="text-white">6681596965</a></li>
                <li>Horario de atención: Estamos de 8am a 8pm todos los días.</li>
                <br>
                <li>Para realizar su pedido váyase al final de la página.</li>
              </ul>              
            </div>
          </div>
        </div>
      </div>
      <div class="navbar navbar-dark bg-dark shadow-sm">
        <div class="container">
          <a href="#" class="navbar-brand d-flex align-items-center">           
            <img src="@/assets/imgs/logo.jpg" alt="Logo">
            <h1>Pastelería Mil Amores</h1>
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
      </div>
    </header>

  </div>
</template>

<script>
export default {
    name: 'Header',
    
    
}
</script>

<style scoped>
header li{
  color:#FFF;
}

ul a {
  padding: 0.3rem;
  text-decoration: none;
  font-size: 1.1rem;  


}
</style>