<template>
    <div>
        <h2 class="display-6 text-center mb-4">Registra tus datos para tu pedido</h2>
          <div class="row ms-1 me-1">
            <div class="row">
              <div class="col-12 col-md-2">
              </div>
              <div class="col-12 col-md-8">
                <label for="exampleFormControlInput1" class="form-label">Nombre</label>
                <input v-model="cliente.nombre" type="text" class="form-control" id="exampleFormControlInput1" placeholder="Tu Nombre">
              </div>
              <div class="col-12 col-md-2">                
              </div>
            </div>
            <div class="row mt-1">
              <div class="col-12 col-md-2">
              </div>
              <div class="col-12 col-md-8">
                <label for="exampleFormControlInput1" class="form-label">Teléfono</label>
                  <input v-model="cliente.telefono" type="text" class="form-control" id="exampleFormControlInput1" placeholder="Tu Teléfono">
              </div>
              <div class="col-12 col-md-2">                
              </div>
            </div>
            <div class="row mt-1">
              <div class="col-12 col-md-2">
              </div>
              <div class="col-12 col-md-8">
                <label for="exampleFormControlInput1" class="form-label">Correo Electrónico</label>
                  <input v-model="cliente.email" type="email" class="form-control" id="exampleFormControlInput1" placeholder="tucorreo@mail.com">
              </div>
              <div class="col-12 col-md-2">                
              </div>
            </div>
            <div class="row mt-1">
              <div class="col-12 col-md-2">
              </div>
              <div class="col-12 col-md-8">
                <label for="exampleFormControlTextarea1" class="form-label">Descripción general del pastel</label>
                  <textarea v-model="cliente.descPastel" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
              </div>
              <div class="col-12 col-md-2">                
              </div>
            </div>

            <div class="col-md-8 mt-2">                 
                <div class="mb-3">                    
                  <button @click="addPedido" class="btn btn-outline-success me-2">Enviar Pedido</button>                  
                  <button type="reset" class="btn btn-outline-danger">Limpiar</button>
                </div>
            </div>   
          </div> 
    </div>
</template>

<script>
export default {
    name: 'Formulario',
    data() {
      return {
        cliente:{}
      }
    },
    methods: {
      addPedido() {
        this.$store.dispatch('addPedidosAction', this.cliente);
        this.cliente = {};
      }
    }
    
    
}
</script>

<style>
  .form-label {
    float: left;
  }

  .mb-3 {
    margin: 0.5rem;    
    
  }
</style>