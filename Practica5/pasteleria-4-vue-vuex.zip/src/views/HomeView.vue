<template>    
  <div class="home">   
    <Header/>   
    <Carousels/>
    <Pasteles/>
    <Sabores/>
    <Decoraciones/>
    <Formulario/>
    <Footer/>    
  </div>

    
</template>

<script>
// @ is an alias to /src
import Header from "../components/Clientes/Header.vue";
import Carousels from "../components/Clientes/Carousels.vue";
import Pasteles from "../components/Clientes/Pasteles.vue";
import Sabores from "../components/Clientes/Sabores.vue";
import Decoraciones from "../components/Clientes/Decoraciones.vue";
import Formulario from "../components/Clientes/Formulario.vue";
import Footer from "../components/Clientes/Footer.vue";


export default {
  name: 'HomeView',
  components: {
    Header,
    Carousels,
    Pasteles,
    Sabores,
    Decoraciones,
    Formulario,
    Footer    
  }
}
</script>



