<template>    
  <div class="home">   
    <Header/>   
    <StockSabores/> 
    <StockDecoraciones/> 
    <Pedidos/> 
    <Footer/>
  </div>

    
</template>

<script>
// @ is an alias to /src
import Header from "../components/Clientes/Header.vue";
import Footer from "../components/Clientes/Footer.vue";
import StockSabores from "../components/Pastelero/StockSabores.vue";
import StockDecoraciones from "../components/Pastelero/StockDecoraciones.vue";
import Pedidos from "../components/Pastelero/Pedidos.vue";





export default {
  name: 'PasteleroView',
  components: {
    Header,   
    Footer,
    StockSabores,
    StockDecoraciones,
    Pedidos
  }
}
</script>



